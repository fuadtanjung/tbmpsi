@extends('layouts.table')

@extends('layouts.app')