<!DOCTYPE html>
<html lang="en">
<head>
    <link href="New folder/css/bootstrap.min.css" rel="stylesheet" />
     
     


      
</head>


<div class="container">
<br>
    <h2 >Daftar User</h2>
    <br>
    <div class="col-md-8" >
        <form action="/">
             <input type="submit" value="Back" class="btn btn-primary"/>
        </form>
          <br><br>
            
        <table class="table border border-primary table2" border="1" id="table2">
            <thead>
                <tr>
                <th scope="col">no</th>
                <th scope="col">id</th>
                <th scope="col">Email</th>
                <th scope="col">Nama</th>
                <th scope="col">Password</th>
                <th scope="col">Aksi</th>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $User; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <tr>
             <th class="text-black "><?php echo e($no++); ?></th>
             <th class="text-black"><?php echo e($data2->id); ?></th>
             <th class="text-black"><?php echo e($data2->email); ?></th>
             <th class="text-black"><?php echo e($data2->name); ?></th>
             <th class="text-black"><?php echo e($data2->password); ?></th>
             
            <th> 
                 <form method="POST" action="/<?php echo e($data2->id); ?>/hapus">
                 <?php echo e(csrf_field()); ?>


                 <input type="submit" name="delete" value="Hapus" class="btn btn-danger"/>

                 <input type="hidden" name="_method" value="DELETE">
                 
                 
                 </form>
                </th>
             </tr> 
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            </table>
    </div>

</div>

</div>
   