<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header text-center">Selamat Datang Admin</div>
                <!-- Sidebar -->
                <ul class="sidebar navbar-nav">
                    <li class="nav-item active">
                    <a class="nav-link" href="/tab">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Pengaduan</span>
                    </a>
                    </li>
                
                <li class="nav-item">
                    <a class="nav-link" href="/tab2">
                    <i class="fas fa-fw fa-table"></i>
                    <span>Users</span></a>
                    </li>

                </ul>

                
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>