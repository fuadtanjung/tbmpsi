
<!doctype html>
    <head>
        <meta charset="utf-8">
        <title>Laporan</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="icon" type="image/png" href="favicon.ico">

        <!--Google Font link-->
        <link href="https://fonts.googleapis.com/css?family=Ubuntu:300,300i,400,400i,500,500i,700,700i" rel="stylesheet">


        <link rel="stylesheet" href="assets/css/swiper.min.css">
        <link rel="stylesheet" href="assets/css/animate.css">
        <link rel="stylesheet" href="assets/css/iconfont.css">
        <link rel="stylesheet" href="assets/css/font-awesome.min.css">
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/css/magnific-popup.css">
        <link rel="stylesheet" href="assets/css/bootsnav.css">



        <!--For Plugins external css-->
        <!--<link rel="stylesheet" href="assets/css/plugins.css" />-->
        <!--Theme custom css -->
        <link rel="stylesheet" href="assets/css/style.css">

        <!--Theme Responsive css-->
        <link rel="stylesheet" href="assets/css/responsive.css" />

        <script src="assets/js/vendor/modernizr-2.8.3-respond-1.4.2.min.js"></script>
    </head>

    <body data-spy="scroll" data-target=".navbar-collapse">


        <!-- Preloader -->
        <div id="loading">
            <div id="loading-center">
                <div id="loading-center-absolute">
                    <div class="object" id="object_one"></div>
                    <div class="object" id="object_two"></div>
                    <div class="object" id="object_three"></div>
                    <div class="object" id="object_four"></div>
                </div>
            </div>
        </div><!--End off Preloader -->


        <div class="culmn">
            <!--Home page style-->


            <nav class="navbar navbar-default bootsnav navbar-fixed white no-background">
                <div class="container">



                    <!-- Start Header Navigation -->
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                            <i class="fa fa-bars"></i>
                        </button>
                        <a class="navbar-brand" >
                            <img src="assets/images/Mpsi.jpg" class="logo logo-display" alt="" width="40" height="40">
                            <img src="assets/images/Mpsi.jpg" class="logo logo-scrolled" alt="" width="40" height="40">
                        </a>

                    </div>
                    <!-- End Header Navigation -->

                    <!-- navbar menu -->
                    <div class="collapse navbar-collapse" id="navbar-menu">
                        <ul class="nav navbar-nav navbar-center">
                            <li><a href="#home">Home</a></li>
                            <li><a href="#download">Review</a></li>
                        </ul>
                    </div><!-- /.navbar-collapse -->
                </div>
            </nav>

            <!--Home Sections-->

            <section id="home" class="home">
                <div class="container">
                    <div class="row">
                        <div class="main_home">
                            <div class="col-md-6">
                                <div class="home_text">
                                    <h1 class="text-white">Selamat Datang</h1>
                                </div>

                                <div class="col-md-5">
                                   <form method="post" action="/" enctype="multipart/form-data">
                                     <?php echo e(csrf_field()); ?>

                                    <div class="form-group">
                                    <label class="text-black" >Nama:</label>
                                    <input type="text" value="" name="var_nama">
                                    </div>

                                      <div class="form-group">
                                      <label class="text-black">No.Identitas:</label>
                                      <input  name="int_no_idt">
                                      </div>

                                          <div class="form-group">
                                          <label class="text-black">Pengaduan:</label>
                                          <textarea name="var_peng" rows="5" cols="50"></textarea>
                                          </div>

                                  <div class="form-group">
                                    <label class="text-black">Masukkan File:</label>
                                    <input type="file" class="form-control-file"  name="file">
                                  </div>

                                      <button type="submit" value="submit" name="submit" class="btn btn-default">Submit</button>
                                    </form>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="phone_one phone_attr1 text-center sm-m-top-10">
                                    <img src="assets/images/Mpsi.jpg" alt="" width="350" />
                                </div>
                            </div>

                        </div>
                        <div class="scrooldown">
                            <a href="#download"><i class="fa fa-chevron-down"></i></a>
                        </div>

                    </div><!--End off row-->
                </div><!--End off container -->
            </section> <!--End off Home Sections-->

  

            <!--App Download Section-->
            <section id="download" class="download m-top-100">
                <div class="download_overlay"></div>
                <div class="container">
                    <div class="row">
                        <div class="main_download ">
                            <div class="col-md-11">
                                <div class="download_item roomy-100">
                                    <h2 class="text-white">Daftar Pelaporan</h2>




                                      <table class="table" border="5">
                                          <thead>

                                            <tr>
                                              <th scope="col" class="text-black">No.</th>
                                              <th scope="col" class="text-black">Pengaduan</th>
                                              <th scope="col" class="text-black">File</th>
                                              <!-- <th scope="col" class="text-black">File</th> -->
                                            </tr>

                                          </thead>

                                          <tbody>
                                              <?php $__currentLoopData = $laporan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                  <tr>
                                                  <th class="text-black"><?php echo e($no++); ?></th>
                                                  <th class="text-black"><?php echo e($data->peng); ?></th>
                         <th><img src="/upload/<?php echo e($data->file); ?>" width="150" height="150"></th>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          </tbody>

                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- scroll up-->
            <div class="scrollup">
                <a href="#home"><i class="fa fa-chevron-up"></i></a>
            </div><!-- End off scroll up -->


            <footer id="footer" class="footer bg-black">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <nav class="navbar navbar-default bootsnav footer-menu no-background">
                                <div class="container">



                                    <!-- Start Header Navigation -->
                                    <div class="navbar-header">
                                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-footer">
                                            <i class="fa fa-bars"></i>
                                        </button>
                                    </div>
                                    <!-- End Header Navigation -->

                                    <!-- navbar menu -->
                                    
                                </div>
                            </nav>
                        </div>
                        <div class="divider"></div>
                        <div>
                        </div>
                        <div class="col-md-12">
                            <div class="main_footer text-center p-top-40 p-bottom-30">
                                <p class="wow fadeInRight" data-wow-duration="1s">
                                    Made with
                                    <i class="fa fa-heart"></i>
                                    by
                                    <a target="_blank">Kelompok 4 MPSI</a>
                                    2018. All Rights Reserved
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </footer>




        </div>

        <!-- JS includes -->

        <script src="assets/js/vendor/jquery-1.11.2.min.js"></script>
        <script src="assets/js/vendor/bootstrap.min.js"></script>

        <script src="assets/js/jquery.magnific-popup.js"></script>
        <script src="assets/js/jquery.easing.1.3.js"></script>
        <script src="assets/js/swiper.min.js"></script>
        <script src="assets/js/jquery.collapse.js"></script>
        <script src="assets/js/bootsnav.js"></script>



        <script src="assets/js/plugins.js"></script>
        <script src="assets/js/main.js"></script>

    </body>
</html>

