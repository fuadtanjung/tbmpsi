<table class="table" border="5">
   <thead>

               <tr>
               <th scope="col" class="text-black">No.</th>
               <th scope="col" class="text-black">Pengaduan</th>
               <!-- <th scope="col" class="text-black">File</th> -->
              </tr>

                                          </thead>

                                          <tbody>
                                              <?php $__currentLoopData = $laporan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                  <tr>
                                                  <th class="text-black"><?php echo e($no++); ?></th>
                                                  <th class="text-black"><?php echo e($data->peng); ?></th>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          </tbody>

                                        </table>